from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import base64
import time

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})


def poll_pubchem_results(listkey):
    """Poll for results using the ListKey"""
    print(f"Polling results for ListKey: {listkey}")
    poll_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/listkey/{listkey}/JSON"
    max_attempts = 10
    attempts = 0

    while attempts < max_attempts:
        try:
            response = requests.get(poll_url)
            response.raise_for_status()
            data = response.json()

            # Check if search is complete
            if 'PC_Compounds' in data:
                return data
            elif 'Waiting' in data:
                time.sleep(1)  # Wait 1 second before polling again
                attempts += 1
            else:
                return None

        except requests.exceptions.RequestException as e:
            print(f"Error polling results: {e}")
            return None

    return None  # Return None if max attempts reached


def get_pubchem_data(formula):
    """Get molecular data from PubChem using chemical formula"""
    try:
        # First search PubChem for the formula
        search_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/formula/{formula}/JSON"
        response = requests.get(search_url)
        response.raise_for_status()
        data = response.json()
        print("pubchem response data", data)
        # Handle asynchronous response
        if 'Waiting' in data:
            listkey = data['Waiting']['ListKey']
            data = poll_pubchem_results(listkey)

            if data is None:
                return None

        # Get the first CID (compound ID)
        cid = data['PC_Compounds'][0]['id']['id']['cid']

        # Get SMILES
        smiles_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/property/CanonicalSMILES/JSON"
        smiles_response = requests.get(smiles_url)
        smiles_response.raise_for_status()
        smiles = smiles_response.json()['PropertyTable']['Properties'][0]['CanonicalSMILES']

        # Get 2D image
        img_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/PNG"
        img_response = requests.get(img_url)
        img_response.raise_for_status()

        return {
            'smiles': smiles,
            'image': base64.b64encode(img_response.content).decode()
        }

    except requests.exceptions.RequestException as e:
        print(f"Error fetching from PubChem: {e}")
        return None
    except (KeyError, IndexError) as e:
        print(f"Error parsing PubChem response: {e}")
        return None


@app.route('/process_formula', methods=['POST'])
def process_formula():
    data = request.json
    formula = data.get('formula', '')
    print("formula", formula)
    result = get_pubchem_data(formula)
    print(result)
    if result is None:
        return jsonify({'error': 'Could not process formula'}), 400

    return jsonify(result)


if __name__ == '__main__':
    app.run(debug=True)