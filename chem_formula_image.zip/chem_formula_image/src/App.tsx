import React from 'react';
import ChemicalVisualizer from './mol_draw';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <ChemicalVisualizer />
      </div>
    </div>
  );
}

export default App;
