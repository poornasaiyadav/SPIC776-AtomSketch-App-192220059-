import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../src/components/ui/card';
import { Input } from '../src/components/ui/input';
import { Button } from '../src/components/ui/button';
import { Alert, AlertDescription } from '../src/components/ui/alert';

const ChemicalVisualizer = () => {
  const [formula, setFormula] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleVisualize = async () => {
    console.log('Formula:', formula);
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('http://127.0.0.1:5000/process_formula', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ formula }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to process formula');
      }
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>Chemical Formula Visualizer</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-4 mb-4">
          <Input
            value={formula}
            onChange={(e) => setFormula(e.target.value)}
            placeholder="Enter chemical formula (e.g., C6H6, H2O)"
            className="flex-grow"
          />
          <Button 
            onClick={handleVisualize}
            disabled={loading}
          >
            {loading ? 'Processing...' : 'Visualize'}
          </Button>
        </div>
        
        {error && (
          <Alert className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {result && (
          <div className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">SMILES Representation:</h3>
              <code className="bg-gray-100 p-2 rounded">{result.smiles}</code>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">2D Structure:</h3>
              <img 
                src={`data:image/png;base64,${result.image}`}
                alt="Molecular structure"
                className="border rounded-lg"
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ChemicalVisualizer;